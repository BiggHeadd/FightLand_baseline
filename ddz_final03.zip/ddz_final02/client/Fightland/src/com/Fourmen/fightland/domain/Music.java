package com.Fourmen.fightland.domain;

import java.applet.AudioClip;
import java.io.*;
import java.applet.Applet;
import java.net.URI;
import java.net.URL;

public class Music{
	public static File f;
	public static URI uri;
	public static URL url;
	public static AudioClip audio;
	public static void getLaunchMusic() {
		try {
			f = new File("src/music/lauch.wav");
			uri = f.toURI();
			url = uri.toURL(); // 解析地址
			audio = Applet.newAudioClip(url);
			audio.loop(); // 循环播放
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	public static void getMainMusic() {
		try {
			f = new File("src/music/main.wav");
			uri = f.toURI();
			url = uri.toURL(); // 解析地址
			audio = Applet.newAudioClip(url);
			audio.loop(); // 循环播放
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	public static void stopMusic() {
		try {
			audio.stop();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}