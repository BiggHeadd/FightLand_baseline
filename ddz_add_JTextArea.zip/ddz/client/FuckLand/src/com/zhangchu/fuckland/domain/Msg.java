package com.zhangchu.fuckland.domain;

import java.io.Serializable;
import java.util.List;

public class Msg implements Serializable{

	private static final long serialVersionUID = -3911518404188182583L;
	
	private int id;
	private List<Poker> list;
	private int chat_flag;
	private String message;
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public List<Poker> getList() {
		return list;
	}
	public void setList(List<Poker> list) {
		this.list = list;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	public void setChat_flag(int chat_flag) {
		this.chat_flag = chat_flag;
	}
	public int getChat_flag() {
		return this.chat_flag;
	}
	@Override
	public String toString() {
		return "Msg [id=" + id + ", list=" + list + ", flag_chat=" + chat_flag +  ", message=" + message + "]";
	}
	public Msg(int id, List<Poker> list, int chat_flag) {
		super();
		this.id = id;
		this.list = list;
		this.chat_flag = chat_flag;
	}
	
	public Msg(int id, List<Poker> list, int chat_flag, String message) {
		super();
		this.id = id;
		this.list = list;
		this.chat_flag = chat_flag;
		this.message = message;
	}
	public Msg() {
		super();
	}
	

}
