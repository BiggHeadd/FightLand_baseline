package com.zhangchu.fuckland.servers;

import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.JButton;
import javax.swing.JTextField;
import com.zhangchu.fuckland.socket.Connect;
import com.alibaba.fastjson.JSON;
import com.zhangchu.fuckland.domain.Msg;
import com.zhangchu.fuckland.frame.main.MainFrame;

public class OutChatEvent implements MouseListener{

	private JButton Send;
	private JTextField messagge_field;
	
	public OutChatEvent(JButton send, JTextField message) {
		this.Send = send;
		this.messagge_field = message;
	}
	
	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}
	
	@Override
	public void mouseClicked(MouseEvent e) {
		// TODO Auto-generated method stub
		System.out.println("����� ���� ��ť");
		String message = this.messagge_field.getText();
		
		System.out.println(JSON.toJSONString(new Msg(MainFrame.myId,null,1,message)));
		Connect.sendMes.setMsg(JSON.toJSONString(new Msg(MainFrame.myId,null,1,message)));
	}
}
