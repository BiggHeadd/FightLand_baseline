package com.Fourmen.fightland.frame.main;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

import com.Fourmen.fightland.domain.MyFrame;
import com.Fourmen.fightland.socket.Connect;

public class Fightland extends MyFrame {

	private static final long serialVersionUID = 881792201169758236L;
	
	private static JButton jButton;
	public static JTextField jTextField;
	public static JTextField jTextField2;
	public static JLabel peoples;
	public static Fightland fightland;
	public static void main(String[] args) {
		fightland = new Fightland();
		fightland.setLayout(null);
		fightland.setSize(450, 250);
		fightland.setLocationRelativeTo(null);// 设置居中，要放在设置窗口大小之后
		
		Font font=new Font("微软雅黑", 1, 13) ;
		
		JLabel jLabel=new JLabel("请输入姓名:");
		jLabel.setFont(font);
		jLabel.setBounds(55, 20, 110, 20);
		
		jTextField=new JTextField();
		jTextField.setFont(font);
		jTextField.setBounds(162, 10, 250,35);
		
		JLabel jLabelip = new JLabel("请输入局域网IP地址:");
		jLabelip.setFont(font);
		jLabelip.setBounds(40, 60, 150, 60);
		
		jTextField2=new JTextField();
		jTextField2.setFont(font);
		jTextField2.setBounds(162, 70, 250, 35);
		
		JLabel jLabel2=new JLabel("当前人数:");
		jLabel2.setFont(font);
		jLabel2.setBounds(180, 100, 230, 60);
		
		peoples=new JLabel("0");
		peoples.setFont(font);
		peoples.setBounds(242, 100, 180, 60);
		
		jButton=new JButton("准     备");
		jButton.setBounds(85,160, 300, 50);
		jButton.setFont(font);
		
		jButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String name=jTextField.getText();
				if(name!=null&&name.length()>0){
					jButton.setEnabled(false);
					boolean b=Connect.connect();
					if(b){
						
					}
				}else{
					JOptionPane.showMessageDialog(null, new JLabel("<html><h2><font color='red'>请输入姓名</font></h2></html>"), "提示", JOptionPane.INFORMATION_MESSAGE); 
				}
			}
		});
		
		fightland.add(jButton);
		fightland.add(peoples);
		fightland.add(jLabel2);
		fightland.add(jTextField);
		fightland.add(jLabel);
		fightland.add(jLabelip);
		fightland.add(jTextField2);
		fightland.repaint();
	}
	

}

