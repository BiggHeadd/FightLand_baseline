package com.Fourmen.fightland.frame.main;

import javax.swing.ImageIcon;
import javax.swing.JLabel;

public class Showillegal extends Thread{
	private JLabel jLabel=new JLabel();
	private String illegalName;
	
	public Showillegal(String illegalName) {
		this.illegalName = illegalName;
	}
	public void run() {
		try {
			jLabel.setIcon(new ImageIcon(MainFrame.class.getClassLoader().getResource("image/"+illegalName+".png")));
			jLabel.setBounds(40, 30, 1000, 50);
			MainFrame.showOutPokerPanel.add(jLabel);
			MainFrame.mainFrame.repaint();
			Thread.sleep(1300);
			
			MainFrame.showOutPokerPanel.remove(jLabel);
			MainFrame.mainFrame.repaint();
			
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
