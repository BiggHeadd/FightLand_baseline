package com.Fourmen.fightland.servers;

import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.text.DateFormat;

import javax.swing.JButton;
import javax.swing.JTextField;
import com.Fourmen.fightland.socket.Connect;
import com.alibaba.fastjson.JSON;
import com.Fourmen.fightland.domain.Msg;
import com.Fourmen.fightland.frame.main.MainFrame;
import java.util.Date;

public class OutChatEvent implements MouseListener{

	private JButton Send;
	private JTextField messagge_field;
	
	public OutChatEvent(JButton send, JTextField message) {
		this.Send = send;
		this.messagge_field = message;
	}
	
	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}
	
	@Override
	public void mouseClicked(MouseEvent e) {
		// TODO Auto-generated method stub
		System.out.println("点击了 发送 按钮");
		Date now = new Date();
		 DateFormat df = DateFormat.getTimeInstance();
		String message = MainFrame.getMyName() + "  " + df.format(now) + '\n' + " " + this.messagge_field.getText();
		
		System.out.println(JSON.toJSONString(new Msg(MainFrame.myId,null,1,message)));
		Connect.sendMes.setMsg(JSON.toJSONString(new Msg(MainFrame.myId,null,1,message)));
		MainFrame.textChat.setText("");
	}
}

