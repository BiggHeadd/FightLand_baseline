package com.Fourmen.fightland.servers;

public class RemoveDirtyWord{
	public RemoveDirtyWord(){
		this(new String[] {}, new char[] {});
	}
	public RemoveDirtyWord(String[] dirty_words, char[] symbols){
		this.dirty_words = dirty_words;
		this.symbols = symbols;
		quickSort(this.dirty_words, 0, dirty_words.length - 1);
	}
	/**
	 * insert a dirty word
	 */
	public void insert(String dirty_word){
		/**
		 * insert a dirty word
		 */
		String[] new_dirty_words = new String[dirty_words.length + 1];
		for(int i = 0, j = 0, k = 0; j < new_dirty_words.length; j++){
			if(k == 0 && dirty_words[i].compareTo(dirty_word) >= 0){
				k += 1;
				new_dirty_words[j] = dirty_word;
			}
			else
				new_dirty_words[j] = dirty_words[i++];
		}
		dirty_words = new_dirty_words;
	}
	/**
	 * remove a dirty word
	 */
	public void remove(String dirty_word){
		/**
		 * remove a dirty word
		 */
		int pos = search(dirty_word);
		if(pos == -1)
			return;
		String[] new_dirty_words = new String[dirty_words.length - 1];
		for(int i = 0, j = 0; i < dirty_words.length; i++){
			if(i == pos)
				continue;
			new_dirty_words[j++] = dirty_words[i];
		}
		dirty_words = new_dirty_words;
	}
	/**
	 * return a string that has been replaced all dirty words to '*'
	 */
	public String process(String dirty_word){
		/**
		 *return a string that has been replaced all dirty words to '*'
		 */
		String result = new String("");
		for(int i = 0, j = i + 1; j <= dirty_word.length() + 1; j++){
			if(j == dirty_word.length() + 1){
				result += dirty_word.substring(i, j - 1);
				continue;
			}
			if(j - i == 1 && isSymbol(dirty_word.charAt(i))){
				result += dirty_word.substring(i, j);
				i += 1;
				continue;
			}
			int check_result = check(dirty_word.substring(i, j));
			if(check_result == 0){
				result += dirty_word.substring(i, i + 1);
				j = ++i;
			}
			else if(check_result == 2){
				result += starString(j - i);
				i = j;
			}
		}
		return result;
	}
	public static void main(String[] args){
		String experimental = new String("操  你妈");
		RemoveDirtyWord rdw = new RemoveDirtyWord(new String[] {"操你妈", "叼你老母", "仆街", "扑街" ,"傻下傻下", "死蠢", "痴线", "废柴", "冚家铲", "冚家富贵", "大番薯", "薯头薯脑", "懵惺惺", "乌薯", "叼你吖", "叼你", "屌你", "屌", "仆街", "粉肠", "嗦嘅", "死发瘟", "发瘟", "蠢过只猪", "傻庚庚", "傻傻地", "死傻", "戆居", "食懵你吖", "食懵你", "你都拾戆嘅", "戆居", "痴妈根", "嗦咗", "痴线"}, new char[] {' ', '%'});
		System.out.println(rdw.process(experimental));
	}

	/**
	 * a string array of dirty words
	 */
	private String[] dirty_words;
	/**
	 * a character array of ignorable symbols
	 */
	private char[] symbols;
	private String starString(int length){
		String star = new String("");
		for(int i = 0; i < length; i++)
			star += new String("*");
		return star;
	}
	private int search(String dirty_word){
		int l = 0, r = dirty_words.length;
//		[l, r)
		while(l < r){
			int mid = (l + r) >> 1;
			if(dirty_words[mid].compareTo(dirty_word) == 0)
				return mid;
			else if(dirty_words[mid].compareTo(dirty_word) < 0)
				l = mid + 1;
			else
				r = mid;
		}
		return -1;
	}
	private boolean isSymbol(char ch){
		for(int i = 0; i < symbols.length; i++)
			if(ch == symbols[i])
				return true;
		return false;
	}
	private String removeSymbols(String dirty_word){
		String result = new String("");
		for(int i = 0; i < dirty_word.length(); i++)
			if(!isSymbol(dirty_word.charAt(i)))
				result += dirty_word.substring(i, i + 1);
		return result;
	}
	private int check(String dirty_word){
		dirty_word = removeSymbols(dirty_word);
		int l = 0, r = dirty_words.length;
//		[l, r)
		while(l < r){
			int mid = (l + r) >> 1;
			if(dirty_words[mid].substring(0, Math.min(dirty_words[mid].length(), dirty_word.length())).compareTo(dirty_word) == 0){
				boolean full_match = false;
				for(int i = mid; i >= 0 && dirty_words[i].substring(0, Math.min(dirty_words[i].length(), dirty_word.length())).compareTo(dirty_word) == 0; i--){
					if(dirty_words[i].length() == dirty_word.length()){
						full_match = true;
						break;
					}
				}
				return 1 + (full_match ? 1 : 0);
			}
			else if(dirty_words[mid].substring(0, Math.min(dirty_words[mid].length(), dirty_word.length())).compareTo(dirty_word) < 0)
				l = mid + 1;
			else
				r = mid;
		}
		return 0;
	}
	private void quickSort(String[] strings, int l, int r){
		if(l >= r)
			return;
		int u = l, v = r;
		while(u < v){
			while(strings[v].compareTo(strings[l]) >= 0 && u < v)
				v--;
			while(strings[u].compareTo(strings[l]) <= 0 && u < v)
				u++;
			String tmp = strings[u];
			strings[u] = strings[v];
			strings[v] = tmp;
		}
		String tmp = strings[l];
		strings[l] = strings[u];
		strings[u] = tmp;
		quickSort(strings, l, u - 1);
		quickSort(strings, v + 1, r);
	}	
}
